package com.jhstudios.clipstudio

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.view.setPadding
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.Locale
import kotlin.math.max

class MainActivity : ComponentActivity() {
    private val bg = Color.rgb(9, 9, 12)
    private val panel = Color.rgb(18, 18, 23)
    private val red = Color.rgb(243, 38, 62)
    private val white = Color.rgb(245, 245, 247)
    private val muted = Color.rgb(150, 150, 163)
    private var videoUri: Uri? = null
    private var videoDurationMs = 0L
    private var player: ExoPlayer? = null
    private var transformer: Transformer? = null
    private var isBusy = false
    private var pendingExportFile: File? = null
    private var pendingSubtitle = ""
    private lateinit var playerView: PlayerView
    private lateinit var status: TextView
    private lateinit var startInput: EditText
    private lateinit var endInput: EditText
    private lateinit var transcriptInput: EditText
    private lateinit var aspect: Spinner
    private lateinit var quality: Spinner
    private lateinit var progress: ProgressBar
    private lateinit var exportButton: Button
    private val openVideo = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) loadVideo(uri)
    }
    private val saveVideo = registerForActivityResult(ActivityResultContracts.CreateDocument("video/mp4")) { uri ->
        if (uri != null) copyExport(uri)
    }
    private val saveText = registerForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri ->
        if (uri != null) try { contentResolver.openOutputStream(uri)?.bufferedWriter(Charsets.UTF_8)?.use { it.write(pendingSubtitle) }; say("Arquivo de texto salvo.") } catch (e: Exception) { say("Falha ao salvar: ${e.message}") }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg; window.navigationBarColor = bg
        buildUi()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg) }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14)); setBackgroundColor(bg) }
        val header = TextView(this).apply { text = "JH CLIP STUDIO\nPRO VIDEO WORKSPACE"; setTextColor(white); textSize = 20f; setTypeface(null, 1); setPadding(0, dp(10), 0, dp(14)) }
        content.addView(header)
        val importBtn = button("＋  Importar vídeo", true) { if (!isBusy) openVideo.launch(arrayOf("video/*")) }
        content.addView(importBtn, matchWrap())
        status = label("Aguardando vídeo. Escolha um MP4 ou outro formato compatível.", muted, 12f)
        content.addView(status)
        playerView = PlayerView(this).apply { useController = true; setBackgroundColor(Color.BLACK); layoutParams = LinearLayout.LayoutParams(-1, dp(230)).apply { topMargin = dp(10); bottomMargin = dp(10) } }
        content.addView(playerView)
        section(content, "01. ESTÚDIO DE EDIÇÃO")
        val timeRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        startInput = edit("Início em segundos", "0")
        endInput = edit("Fim em segundos", "30")
        timeRow.addView(startInput, LinearLayout.LayoutParams(0, dp(52), 1f).apply { marginEnd = dp(6) })
        timeRow.addView(endInput, LinearLayout.LayoutParams(0, dp(52), 1f).apply { marginStart = dp(6) })
        content.addView(timeRow)
        val rangeButtons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        rangeButtons.addView(button("Usar posição atual", false) { player?.let { startInput.setText((it.currentPosition / 1000.0).toString()); endInput.setText((it.currentPosition / 1000.0 + 30).toString()) } }, LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginEnd = dp(5) })
        rangeButtons.addView(button("Pré-visualizar", false) { previewRange() }, LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginStart = dp(5) })
        content.addView(rangeButtons)
        section(content, "02. FORMATO E QUALIDADE")
        aspect = spinner(listOf("Manter proporção original", "Vertical 9:16 (prévia/opção)", "Quadrado 1:1 (prévia/opção)", "Horizontal 16:9 (prévia/opção)"))
        quality = spinner(listOf("Rápida · compatibilidade", "Padrão · recomendada", "Alta · maior processamento"))
        content.addView(label("Formato", muted, 12f)); content.addView(aspect, matchWrap())
        content.addView(label("Perfil de exportação", muted, 12f)); content.addView(quality, matchWrap())
        section(content, "03. CORTES SUGERIDOS")
        content.addView(label("Sugestões por duração. Para escolher os melhores momentos pelo conteúdo, revise a transcrição e ajuste os horários manualmente.", muted, 12f))
        content.addView(button("Encontrar cortes de até 45 s", false) { suggestClips() }, matchWrap())
        section(content, "04. LEGENDAS E TRANSCRIÇÃO")
        transcriptInput = EditText(this).apply { hint = "Digite ou cole a transcrição. Edite as frases e exporte em SRT ou TXT."; setHintTextColor(muted); setTextColor(white); textSize = 14f; gravity = Gravity.TOP; minLines = 4; maxLines = 12; inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE; setPadding(dp(12)); setBackgroundColor(panel) }
        content.addView(transcriptInput, LinearLayout.LayoutParams(-1, dp(135)))
        val subtitleRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        subtitleRow.addView(button("Salvar SRT", false) { saveSubtitle(true) }, LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginEnd = dp(5) })
        subtitleRow.addView(button("Salvar TXT", false) { saveSubtitle(false) }, LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginStart = dp(5) })
        content.addView(subtitleRow)
        section(content, "05. EXPORTAÇÃO")
        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100; progress = 0; visibility = View.GONE }
        content.addView(progress, matchWrap())
        exportButton = button("Exportar corte selecionado", true) { exportClip() }
        exportButton.isEnabled = false
        content.addView(exportButton, matchWrap())
        content.addView(label("Processamento local no aparelho. Vídeos longos ou em alta resolução podem levar tempo e consumir memória. A exportação de corte mantém o enquadramento original; opções de proporção são exibidas como referência nesta versão.", muted, 11f))
        content.addView(button("Limpar projeto", false) { resetProject() }, matchWrap())
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun loadVideo(uri: Uri) {
        try {
            videoUri = uri
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (_: Exception) { videoUri = uri }
        try {
            player?.release()
            player = ExoPlayer.Builder(this).build().also { p ->
                playerView.player = p
                p.setMediaItem(MediaItem.fromUri(uri)); p.prepare(); p.playWhenReady = false
                p.addListener(object : Player.Listener {
                    override fun onPlaybackStateChanged(playbackState: Int) {
                        if (playbackState == Player.STATE_READY) {
                            videoDurationMs = max(0L, p.duration)
                            if (videoDurationMs > 0) endInput.setText(String.format(Locale.US, "%.1f", minOf(30.0, videoDurationMs / 1000.0)))
                            exportButton.isEnabled = true
                            say("Vídeo carregado · ${formatTime(videoDurationMs / 1000.0)}")
                        }
                    }
                })
            }
        } catch (e: Exception) { say("Não foi possível abrir o vídeo: ${e.message}") }
    }

    private fun previewRange() {
        val p = player ?: return
        val start = (startInput.text.toString().toDoubleOrNull() ?: 0.0).coerceAtLeast(0.0)
        val end = endInput.text.toString().toDoubleOrNull() ?: 0.0
        if (end <= start) { say("O fim precisa ser maior que o início."); return }
        p.seekTo((start * 1000).toLong()); p.play()
        p.addListener(object : Player.Listener {
            override fun onEvents(player: Player, events: Player.Events) {
                if (player.currentPosition >= (end * 1000).toLong()) player.pause()
            }
        })
    }

    private fun suggestClips() {
        if (videoDurationMs <= 0) { say("Importe um vídeo primeiro."); return }
        val duration = videoDurationMs / 1000.0
        val start = (player?.currentPosition ?: 0L) / 1000.0
        val end = minOf(duration, start + 45.0)
        startInput.setText(String.format(Locale.US, "%.1f", start))
        endInput.setText(String.format(Locale.US, "%.1f", end))
        say("Corte sugerido: ${formatTime(start)} até ${formatTime(end)}. Ajuste o intervalo antes de exportar.")
    }

    private fun exportClip() {
        if (isBusy) return
        val uri = videoUri ?: run { say("Importe um vídeo primeiro."); return }
        val start = startInput.text.toString().toDoubleOrNull() ?: 0.0
        val end = endInput.text.toString().toDoubleOrNull() ?: 0.0
        val duration = videoDurationMs / 1000.0
        if (start < 0 || end <= start || (duration > 0 && end > duration + 0.2)) { say("Intervalo inválido. Use tempos dentro da duração do vídeo."); return }
        isBusy = true; exportButton.isEnabled = false; progress.visibility = View.VISIBLE; progress.progress = 0; say("Preparando exportação...")
        Thread {
            try {
                val input = File(cacheDir, "jh_clip_input_${System.currentTimeMillis()}.mp4")
                contentResolver.openInputStream(uri).use { source -> FileOutputStream(input).use { dest -> source?.copyTo(dest) ?: error("Não foi possível ler o vídeo") } }
                val out = File(cacheDir, "jh_clip_export_${System.currentTimeMillis()}.mp4")
                runOnUiThread { startTransform(input, out, start, end) }
            } catch (e: Exception) {
                runOnUiThread { isBusy = false; exportButton.isEnabled = true; progress.visibility = View.GONE; say("Falha ao preparar vídeo: ${e.message}") }
            }
        }.start()
    }

    private fun startTransform(input: File, out: File, start: Double, end: Double) {
        try {
            val mediaItem = MediaItem.Builder().setUri(Uri.fromFile(input)).setClippingConfiguration(
                MediaItem.ClippingConfiguration.Builder().setStartPositionMs((start * 1000).toLong()).setEndPositionMs((end * 1000).toLong()).build()
            ).build()
            val edited = EditedMediaItem.Builder(mediaItem).build()
            transformer = Transformer.Builder(this).setVideoMimeType(MimeTypes.VIDEO_H264).setAudioMimeType(MimeTypes.AUDIO_AAC).addListener(object : Transformer.Listener {
                override fun onCompleted(composition: androidx.media3.transformer.Composition, exportResult: ExportResult) {
                    pendingExportFile = out
                    runOnUiThread { isBusy = false; exportButton.isEnabled = true; progress.visibility = View.GONE; say("Corte renderizado. Escolha onde salvar o MP4."); saveVideo.launch("JHClipStudio_corte.mp4") }
                    input.delete()
                }
                override fun onError(composition: androidx.media3.transformer.Composition, exportResult: ExportResult, exportException: ExportException) {
                    input.delete(); out.delete()
                    runOnUiThread { isBusy = false; exportButton.isEnabled = true; progress.visibility = View.GONE; say("Falha na exportação: ${exportException.message ?: "codec não compatível ou pouca memória"}") }
                }
            }).build()
            transformer?.start(edited, out.absolutePath)
            say("Renderizando vídeo. Não feche o aplicativo.")
        } catch (e: Exception) { input.delete(); out.delete(); isBusy = false; exportButton.isEnabled = true; progress.visibility = View.GONE; say("Não foi possível iniciar a exportação: ${e.message}") }
    }

    private fun copyExport(destination: Uri) {
        val file = pendingExportFile ?: run { say("Arquivo exportado não encontrado."); return }
        Thread {
            try {
                contentResolver.openOutputStream(destination, "w").use { output -> FileInputStream(file).use { input -> input.copyTo(output ?: error("Não foi possível abrir destino")) } }
                file.delete()
                runOnUiThread { say("MP4 salvo com sucesso.") }
            } catch (e: Exception) { runOnUiThread { say("Falha ao salvar MP4: ${e.message}") } }
        }.start()
    }

    private fun saveSubtitle(srt: Boolean) {
        val text = transcriptInput.text.toString().trim()
        if (text.isBlank()) { say("Digite ou cole a transcrição antes de exportar as legendas."); return }
        pendingSubtitle = if (srt) makeSrt(text) else text + "\n"
        saveText.launch(if (srt) "JHClipStudio_legendas.srt" else "JHClipStudio_transcricao.txt")
    }

    private fun makeSrt(text: String): String {
        val lines = text.lines().filter { it.isNotBlank() }
        if (lines.isEmpty()) return ""
        val start = (startInput.text.toString().toDoubleOrNull() ?: 0.0).coerceAtLeast(0.0)
        val end = (endInput.text.toString().toDoubleOrNull() ?: start + 2.0).coerceAtLeast(start + 0.5)
        val step = (end - start) / lines.size
        return lines.mapIndexed { i, line -> "${i + 1}\n${srtTime(i * step)} --> ${srtTime((i + 1) * step)}\n$line" }.joinToString("\n\n") + "\n"
    }

    private fun srtTime(seconds: Double): String {
        val ms = (seconds * 1000).toLong().coerceAtLeast(0)
        val h = ms / 3600000; val m = (ms % 3600000) / 60000; val s = (ms % 60000) / 1000; val milli = ms % 1000
        return String.format(Locale.US, "%02d:%02d:%02d,%03d", h, m, s, milli)
    }

    private fun resetProject() {
        if (isBusy) return
        player?.release(); player = null; playerView.player = null; videoUri = null; videoDurationMs = 0L
        startInput.setText("0"); endInput.setText("30"); transcriptInput.setText(""); exportButton.isEnabled = false; say("Projeto limpo. Importe outro vídeo para começar.")
    }

    private fun say(message: String) { if (::status.isInitialized) status.text = message }
    private fun formatTime(sec: Double): String { val s = sec.toLong().coerceAtLeast(0); return String.format(Locale.US, "%02d:%02d", s / 60, s % 60) }
    private fun section(parent: LinearLayout, title: String) { val t = label(title, white, 14f); t.setTypeface(null, 1); t.setPadding(0, dp(20), 0, dp(9)); parent.addView(t) }
    private fun label(text: String, color: Int, size: Float) = TextView(this).apply { this.text = text; setTextColor(color); textSize = size; setPadding(0, dp(7), 0, dp(7)) }
    private fun button(text: String, primary: Boolean, action: () -> Unit) = Button(this).apply { this.text = text; isAllCaps = false; setTextColor(white); textSize = 13f; setBackgroundColor(if (primary) red else panel); setOnClickListener { action() }; minimumHeight = dp(44) }
    private fun edit(hintText: String, value: String) = EditText(this).apply { hint = hintText; setHintTextColor(muted); setTextColor(white); setSingleLine(true); inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL; setText(value); setPadding(dp(10)); setBackgroundColor(panel); textSize = 14f }
    private fun spinner(items: List<String>) = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, items); setBackgroundColor(panel) }
    private fun matchWrap() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(5); bottomMargin = dp(5) }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    override fun onDestroy() { player?.release(); transformer?.cancel(); super.onDestroy() }
}
